# Codiscovery - Memory Game

Résultat du live stream

![img](./extras/memory_game.gif)

## Notes

- Pour être notifié du prochain live, abonnez-vous à la chaîne Twitch [jenaiccambre](https://twitch.com/jenaiccambre)
- Pour avoir les prochaines infos pour un prochain live, abonnez-vous au compte Twitter [@jenaiccambre](https://twitter.com/jenaiccambre)